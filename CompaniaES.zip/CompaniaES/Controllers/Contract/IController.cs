﻿using Microsoft.AspNetCore.Mvc;

namespace CompaniaES.Controllers.Contract
{
    public interface IController
    {

        public Task<ActionResult<Object>> Consultar();

        public Task<ActionResult<Object>> ConsultarPorId(string Id);

    }
}
