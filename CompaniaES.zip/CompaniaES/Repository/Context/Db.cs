﻿using Microsoft.EntityFrameworkCore;
using ReyBanPac.ModeloCanonico.Model;

namespace CompaniaES.Repository.Context
{
    public class Db : DbContext
    {
        public Db(DbContextOptions<Db> options) : base(options)
        {

        }
        public DbSet<CompaniaModel> Models => Set<CompaniaModel>();
        public DbSet<CompaniaCaracteristicaModel> CompaniaCaracteristicaModel => Set<CompaniaCaracteristicaModel>();

    }
}
