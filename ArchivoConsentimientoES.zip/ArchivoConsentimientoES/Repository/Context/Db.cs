﻿using ReyBanPac.ModeloCanonico.Model;
using Microsoft.EntityFrameworkCore;

namespace ReyBanPac.ArchivoConsentimientoES.Repository.Context
{
    public class Db : DbContext
    {
        public Db(DbContextOptions<Db> options) : base(options)
        {

        }
        public DbSet<ArchivoConsentimientoModel> Models => Set<ArchivoConsentimientoModel>();
    }
}
