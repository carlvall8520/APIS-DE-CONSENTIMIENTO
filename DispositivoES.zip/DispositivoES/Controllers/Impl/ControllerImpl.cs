﻿using ReyBanPac.DispositivoES.Constans;
using ReyBanPac.DispositivoES.Controllers.Contract;
using ReyBanPac.DispositivoES.Service.Contract;
using ReyBanPac.DispositivoES.Utils;
using Microsoft.AspNetCore.Mvc;
using ReyBanPac.ModeloCanonico.Constans;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;

using Microsoft.AspNetCore.Authorization;
using System.Text.Json;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace ReyBanPac.DispositivoES.Controllers.Impl
{
    [Route("api/" + General.Tipo_Servicio + "/" + General.Nombre_Servicio)]
    [Tags(General.Nombre_Servicio)]
    [ApiController]
	 //[Authorize]
    public class ControllerImpl : ControllerBase, IController
    {
        private readonly ILogger<ControllerImpl> _logger;
        private readonly IService _svc;

        public ControllerImpl(IService Servicio, ILogger<ControllerImpl> logger)
        {
            _svc = Servicio;
            _logger = logger;
        }

        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Consumes(MimeType.JSON)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<Object>> Guardar(DispositivoType EntityType)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Controller");
            try
            {
                DispositivoType resultado;
                resultado = await _svc.Guardar(EntityType);
                return StatusCode(StatusCodes.Status201Created, DataValidator.ValidarResultadoByCreate(resultado));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Controller");
            }
        }

        [HttpPut]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Consumes(MimeType.JSON)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<Object>> Actualizar(DispositivoType EntityType)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Controller");
            try
            {
                DispositivoType resultado;
                resultado = await _svc.Actualizar(EntityType);
                return Ok(DataValidator.ValidarResultadoByUpdate(resultado));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Controller");
            }
        }

        [HttpDelete("{Id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<Object>> Eliminar(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Controller");
            try
            {
                int confirmarEliminacion = await _svc.Eliminar(Id);
                return Ok(DataValidator.ValidarResultadoByDelete(confirmarEliminacion));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Controller");
            }
        }

        [HttpGet]
        [ProducesResponseType(typeof(List<DispositivoType>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<Object>> Consultar()
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Controller");
            try
            {
                List<DispositivoType> listado;
                listado = await _svc.Consultar();
                return Ok(DataValidator.ValidarResultadoConsulta(listado));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Controller");
            }
        }

        [HttpGet("{Id}")]
        [ProducesResponseType(typeof(DispositivoType), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<Object>> ConsultarPorId(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Controller");
            try
            {
                DispositivoType entityType;
                entityType = await _svc.ConsultarPorId(Id);
                return Ok(DataValidator.ValidarResultadoConsulta(entityType));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Controller");
            }
        }

        [HttpGet("identificador/{Id}")]
        [ProducesResponseType(typeof(DispositivoType), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<Object>> ConsultarPorIdentificador(string Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Controller");
            try
            {
                DispositivoType entityType;
                entityType = await _svc.ConsultarPorIdentificador(Id);
                return Ok(DataValidator.ValidarResultadoConsulta(entityType));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Controller");
            }
        }

        [HttpGet("encuesta/{Id_Encuesta}")]
        [ProducesResponseType(typeof(List<DispositivoType>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<Object>> ConsultarDiponibilidadPorIdEncuesta(int Id_Encuesta)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Controller");
            try
            {
                List<DispositivoType> listado;
                listado = await _svc.ConsultarDiponibilidadPorIdEncuesta(Id_Encuesta);
                return Ok(DataValidator.ValidarResultadoConsulta(listado));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Controller");
            }
        }
        

        [HttpPost("permiso")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Consumes(MimeType.JSON)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<Object>> GuardarPermiso(PermisoDispositivoType EntityType)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Controller");
            try
            {
                PermisoDispositivoType resultado;
                resultado = await _svc.GuardarPermiso(EntityType);
                return StatusCode(StatusCodes.Status201Created, DataValidator.ValidarResultadoByCreate(resultado));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Controller");
            }
        }

        [HttpPut("permiso")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Consumes(MimeType.JSON)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<Object>> ActualizarPermiso(PermisoDispositivoType EntityType)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Controller");
            try
            {
                PermisoDispositivoType resultado;
                resultado = await _svc.ActualizarPermiso(EntityType);
                return Ok(DataValidator.ValidarResultadoByUpdate(resultado));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Controller");
            }
        }

        [HttpGet("permiso")]
        [ProducesResponseType(typeof(List<PermisoDispositivoType>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<object>> ConsultarPermiso()
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Controller");
            try
            {
                List<PermisoDispositivoType> listado;
                listado = await _svc.ConsultarPermiso();
                return Ok(DataValidator.ValidarResultadoConsulta(listado));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Controller");
            }
        }

        [HttpGet("permiso/{Identificador}")]
        [ProducesResponseType(typeof(List<PermisoDispositivoType>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<object>> ConsultarPermiso(string Identificador)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Controller");
            try
            {
                List<PermisoDispositivoType> listado;
                listado = await _svc.ConsultarPermiso(Identificador);
                return Ok(DataValidator.ValidarResultadoConsulta(listado));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Controller");
            }
        }

        [HttpGet("permiso/{Id_Encuesta}/{Id_Dispositivo}")]
        [ProducesResponseType(typeof(List<PermisoDispositivoType>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<object>> ConsultarPermisoPorEncuestayDispositivoId(int Id_Encuesta, int Id_Dispositivo)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Controller");
            try
            {
                List<DetallePermisoDispositivoType> listado;
                listado = await _svc.ConsultarPermisoPorEncuestayDispositivoId(Id_Encuesta, Id_Dispositivo);
                return Ok(DataValidator.ValidarResultadoConsulta(listado));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Controller");
            }
        }

        

        [HttpDelete("permiso/{Id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces(MimeType.JSON)]
        public async Task<ActionResult<Object>> EliminarPermiso(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Controller");
            try
            {
                int confirmarEliminacion = await _svc.EliminarPermiso(Id);
                return Ok(DataValidator.ValidarResultadoByDelete(confirmarEliminacion));
            }
            catch (ServiceException ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {ex.Message}");
                return StatusCode(ex.Codigo, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error Interno del Servidor");
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Controller");
            }
        }

    }
}
