﻿using Microsoft.AspNetCore.Mvc;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.DispositivoES.Controllers.Contract
{
    public interface IController
    {
        public Task<ActionResult<Object>> Guardar(DispositivoType EntityType);

        public Task<ActionResult<Object>> Actualizar(DispositivoType EntityType);

        public Task<ActionResult<Object>> Eliminar(int Id);

        public Task<ActionResult<Object>> Consultar();

        public Task<ActionResult<Object>> ConsultarPorId(int Id);

        public Task<ActionResult<Object>> ConsultarPorIdentificador(string Id);

        public Task<ActionResult<Object>> ConsultarDiponibilidadPorIdEncuesta(int Id_Encuesta);
        
        public Task<ActionResult<Object>> GuardarPermiso(PermisoDispositivoType EntityType);

        public Task<ActionResult<Object>> ActualizarPermiso(PermisoDispositivoType EntityType);

        public Task<ActionResult<Object>> ConsultarPermiso();

        public Task<ActionResult<Object>> ConsultarPermiso(string Identificador);

        public Task<ActionResult<Object>> ConsultarPermisoPorEncuestayDispositivoId(int Id_Encuesta, int Id_Dispositivo);

        public Task<ActionResult<Object>> EliminarPermiso(int Id);

    }
}
