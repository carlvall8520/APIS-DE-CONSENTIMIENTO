﻿using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;

namespace ReyBanPac.DispositivoES.Utils
{
    public static class DataValidator
    {
        public static string ValidarResultadoByCreate(DispositivoType EntityType)
        {
            if (EntityType == null)
            {
                throw new ServiceException("Error al crear el registro") { Codigo = StatusCodes.Status400BadRequest };
            }
            return "Registro creado con id: " + EntityType.Id;
        }

        public static string ValidarResultadoByCreate(PermisoDispositivoType EntityType)
        {
            if (EntityType == null)
            {
                throw new ServiceException("Error al crear el registro") { Codigo = StatusCodes.Status400BadRequest };
            }
            return "Registro creado con id: " + EntityType.Id;
        }

        public static string ValidarResultadoByUpdate(DispositivoType EntityType)
        {
            if (EntityType == null)
            {
                throw new ServiceException("Error al actualizar el registro") { Codigo = StatusCodes.Status400BadRequest };
            }
            return "El registro con id: " + EntityType.Id + " fue actualizado de forma exitosa";
        }

        public static string ValidarResultadoByUpdate(PermisoDispositivoType EntityType)
        {
            if (EntityType == null)
            {
                throw new ServiceException("Error al actualizar el registro") { Codigo = StatusCodes.Status400BadRequest };
            }
            return "El registro con id: " + EntityType.Id + " fue actualizado de forma exitosa";
        }

        public static string ValidarResultadoByDelete(int Confirmacion)
        {
            if (Confirmacion == 0)
            {
                throw new ServiceException("Error al eliminar el registro") { Codigo = StatusCodes.Status400BadRequest };
            }
            else
            {
                return "Registro eliminado de forma exitosa";
            }

        }
        public static Object ValidarResultadoConsulta(object Configuracion)
        {
            if (Configuracion != null)
            {
                return Configuracion;
            }
            else
            {
                throw new ServiceException("No hay Contenido") { Codigo = StatusCodes.Status404NotFound };
            }
        }

        public static Object ValidarResultadoConsulta(DispositivoType EntityType)
        {
            if (EntityType != null && EntityType.Id != 0)
            {
                return EntityType;
            }
            else
            {
                throw new ServiceException("No hay Contenido") { Codigo = StatusCodes.Status404NotFound };
            }
        }
    }
}
