﻿using Microsoft.EntityFrameworkCore;
using ReyBanPac.ModeloCanonico.Model;

namespace ReyBanPac.DispositivoES.Repository.Context
{
    public class Db : DbContext
    {
        public Db(DbContextOptions<Db> options) : base(options)
        {

        }
        public DbSet<DispositivoModel> Models => Set<DispositivoModel>();
        public DbSet<PermisoDispositivoModel> PermisoModels => Set<PermisoDispositivoModel>();

        public DbSet<EncuestaModel> EncuestaModel => Set<EncuestaModel>();
        public DbSet<HaciendaModel> HaciendaModel => Set<HaciendaModel>();
        public DbSet<ZonaModel> ZonaModel => Set<ZonaModel>();
        public DbSet<EmpleadoHaciendaModel> EmpleadoHaciendaModel => Set<EmpleadoHaciendaModel>();

    }
}
