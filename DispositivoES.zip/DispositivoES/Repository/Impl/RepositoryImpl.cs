﻿using ReyBanPac.DispositivoES.Constans;
using ReyBanPac.DispositivoES.Repository.Context;
using ReyBanPac.DispositivoES.Repository.Contract;
using Microsoft.EntityFrameworkCore;
using ReyBanPac.ModeloCanonico.Constans;
using ReyBanPac.ModeloCanonico.Model;
using ReyBanPac.ModeloCanonico.Type;
using ReyBanPac.ModeloCanonico.Utils;


namespace ReyBanPac.DispositivoES.Repository.Impl
{
    public class RepositoryImpl : IRepository
    {
        private readonly Db db;
        private readonly ILogger<RepositoryImpl> _logger;
        public RepositoryImpl(Db dbContex, ILogger<RepositoryImpl> logger)
        {
            this.db = dbContex;
            _logger = logger;
        }

        public async Task<DispositivoModel> Guardar(DispositivoModel EntityModel)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");
            try
            {
                EntityModel.Fecha_Creacion = DateTime.Now;
                var Item = db.Models.Add(EntityModel);
                await db.SaveChangesAsync();
                return Item.Entity;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }

        public async Task<DispositivoModel> Actualizar(DispositivoModel EntityModel)
        {
            try
            {
                EntityModel.Fecha_Actualizacion = DateTime.Now;
                var Item = db.Models.Add(EntityModel);
                db.Entry(EntityModel).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return Item.Entity;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }

        public async Task<int> Eliminar(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");

            try
            {
                var Reg = await db.Models.FindAsync(Id) ?? new DispositivoModel();

                Reg.Fecha_Actualizacion = DateTime.Now;
                Reg.Estado = Estados.ELIMINADO;
                db.Models.Add(Reg);
                db.Entry(Reg).State = EntityState.Modified;
                return await db.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }

        public async Task<List<DispositivoModel>> Consultar()
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");

            try
            {
                return await db.Models.Where(x => x.Estado != Estados.ELIMINADO).ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }

        public async Task<DispositivoModel> ConsultarPorId(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");

            try
            {
                return await db.Models.FindAsync(Id) ?? new DispositivoModel();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }


        public async Task<DispositivoModel> ConsultarPorIdentificador(string Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");

            try
            {
                return await db.Models.Where(x => x.Identificador.Equals(Id)).FirstOrDefaultAsync() ?? new DispositivoModel();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }


        public async Task<List<DispositivoModel>> ConsultarDiponibilidadPorIdEncuesta(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");

            try
            {
                DateTime FechaHoy = DateTime.Today;

                //Todos los dispositivos
                var Dispositivos = await db.Models.Where(x=> x.Estado == Estados.ACTIVO).ToListAsync();

                //Consulta dispositivos con permisos
                var ConPermisos = await (from d in db.Models
                                   join dp in db.PermisoModels on d.Id equals dp.Id_Dispositivo
                                   join e in db.EncuestaModel on dp.Id_Encuesta equals e.Id
                                   where
                                       d.Estado == Estados.ACTIVO &&
                                       dp.Estado == Estados.ACTIVO &&
                                       dp.Id_Encuesta != Id &&
                                       e.Estado == Estados.ACTIVO &&
                                       e.Fecha_Inicio <= FechaHoy &&
                                       e.Fecha_Fin >= FechaHoy
                                   select d).ToListAsync();



                return Dispositivos.Except(ConPermisos).ToList();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }



        public async Task<bool> ValidarExistenciaPermiso(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");

            try
            {
                return await db.PermisoModels.AnyAsync(item => item.Id == Id && item.Estado != Estados.ELIMINADO);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }

        public async Task<bool> ValidarExistencia(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");

            try
            {
                return await db.Models.AnyAsync(item => item.Id == Id && item.Estado != Estados.ELIMINADO);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }

        public async Task<bool> ValidarExistencia(string Identificador)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");

            try
            {
                return await db.Models.AnyAsync(item => item.Identificador == Identificador && item.Estado != Estados.ELIMINADO);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }


        public async Task<PermisoDispositivoModel> GuardarPermiso(PermisoDispositivoModel EntityModel)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");
            try
            {
                EntityModel.Fecha_Creacion = DateTime.Now;
                var Item = db.PermisoModels.Add(EntityModel);
                await db.SaveChangesAsync();
                return Item.Entity;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }

        public async Task<PermisoDispositivoModel> ActualizarPermiso(PermisoDispositivoModel EntityModel)
        {
            try
            {
                EntityModel.Fecha_Actualizacion = DateTime.Now;
                var Item = db.PermisoModels.Add(EntityModel);
                db.Entry(EntityModel).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return Item.Entity;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }


        public async Task<List<PermisoDispositivoType>> ConsultarPermiso()
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");

            try
            {
                return await (from d in db.Models
                              join dp in db.PermisoModels on d.Id equals dp.Id_Dispositivo
                              where d.Estado != Estados.ELIMINADO && dp.Estado != Estados.ELIMINADO
                              select new PermisoDispositivoType
                              {
                                  Id = dp.Id,
                                  Id_Dispositivo = dp.Id_Dispositivo,
                                  Id_Encuesta = dp.Id_Encuesta,
                                  Id_Hacienda = dp.Id_Hacienda,
                                  Estado = dp.Estado,
                              }
                              ).ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }


        public async Task<List<PermisoDispositivoType>> ConsultarPermiso(string Identificador)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");

            try
            {
                DateTime FechaHoy = DateTime.Today;

                var Dispositivo = db.Models.Where(x => x.Identificador == Identificador).FirstOrDefault();
                if (Dispositivo != null)
                {
                    return await (from d in db.Models
                                  join dp in db.PermisoModels on d.Id equals dp.Id_Dispositivo
                                  join e in db.EncuestaModel on dp.Id_Encuesta equals e.Id
                                  where d.Estado == Estados.ACTIVO &&
                                        dp.Estado == Estados.ACTIVO &&
                                        e.Estado == Estados.ACTIVO &&
                                        e.Fecha_Inicio <= FechaHoy &&
                                        e.Fecha_Fin >= FechaHoy &&
                                        d.Identificador == Identificador

                                  select new PermisoDispositivoType
                                  {
                                      Id = dp.Id,
                                      Id_Dispositivo = dp.Id_Dispositivo,
                                      Id_Encuesta = dp.Id_Encuesta,
                                      Id_Hacienda = dp.Id_Hacienda,
                                      Estado = dp.Estado
                                  }).ToListAsync();
                }
                else
                {
                    throw new ServiceException("Dispositivo no existe") { Codigo = StatusCodes.Status400BadRequest };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }

        public async Task<List<DetallePermisoDispositivoType>> ConsultarPermisoPorEncuestayDispositivoId(int Id_Encuesta, int Id_Dispositivo)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");

            try
            {
                return await (from dp in db.PermisoModels
                              join d in db.Models on dp.Id_Dispositivo equals d.Id
                              join e in db.EncuestaModel on dp.Id_Encuesta equals e.Id
                              join h in db.HaciendaModel on dp.Id_Hacienda equals h.Id
                              join eh in db.EmpleadoHaciendaModel on h.Id equals eh.Id_Hacienda
                              join z in db.ZonaModel on eh.Id_Zona equals z.Id

                              where dp.Id_Encuesta == Id_Encuesta
                                    && dp.Id_Dispositivo == Id_Dispositivo
                                    && dp.Estado != Estados.ELIMINADO
                                    && d.Estado == Estados.ACTIVO
                                    && e.Estado == Estados.ACTIVO
                                    && h.Estado == Estados.ACTIVO
                                    && eh.Estado == Estados.ACTIVO
                                    && z.Estado == Estados.ACTIVO
                                    
                              select new DetallePermisoDispositivoType
                              {
                                  Id = dp.Id,
                                  Id_Hacienda = h.Id,
                                  Hacienda = h.Nombre,
                                  Id_Dispositivo = d.Id,
                                  Dispositivo = d.Nombre,
                                  Identificador = d.Identificador,
                                  Id_Encuesta = e.Id,
                                  Encuesta = e.Nombre,
                                  Id_Zona = z.Id,
                                  Zona = z.Nombre,
                                  Estado = dp.Estado
                              }
                    ).Distinct().ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }

        public async Task<int> EliminarPermiso(int Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");

            try
            {
                var Reg = await db.PermisoModels.FindAsync(Id) ?? new PermisoDispositivoModel();

                Reg.Fecha_Actualizacion = DateTime.Now;
                Reg.Estado = Estados.ELIMINADO;
                db.PermisoModels.Add(Reg);
                db.Entry(Reg).State = EntityState.Modified;
                return await db.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }

    }
}
